/* Зов леса: ядро.
   Даты, хранилище с синхронизацией (Supabase через ../bioviz/x/cloud.js, коллекция 'bamboo'),
   отметки ШАДа (коллекция 'shad', общая с трекером shad/), расчёт опыта, уровня и леса.
   Опыт не хранится: он каждый раз считается из записей, поэтому два устройства не могут разойтись. */
(function(){
const B = window.B = {};

/* ---------- мелочи ---------- */
const pad = n => String(n).padStart(2, '0');
B.pad = pad;
B.esc = s => String(s == null ? '' : s).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
B.uid = () => Date.now().toString(36) + Math.random().toString(36).slice(2, 6);
B.clamp = (x, a, b) => Math.max(a, Math.min(b, x));
B.plural = (n, one, few, many) => {
  const a = Math.abs(n) % 100, b = a % 10;
  if (a > 10 && a < 20) return many;
  if (b === 1) return one;
  if (b > 1 && b < 5) return few;
  return many;
};
B.num = (x, d = 0) => Number(x).toLocaleString('ru-RU', {maximumFractionDigits: d, minimumFractionDigits: 0});

/* ---------- даты ----------
   День заканчивается в 4 утра: разбор, написанный в половине второго ночи, относится ко вчерашнему дню. */
const SHIFT = 4 * 3600e3;
B.ymd = d => `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
B.dayOf = ts => B.ymd(new Date(ts - SHIFT));
B.today = () => B.dayOf(Date.now());
B.parse = s => { const [y, m, d] = s.split('-').map(Number); return new Date(y, m - 1, d, 12); };
B.add = (s, k) => { const d = B.parse(s); d.setDate(d.getDate() + k); return B.ymd(d); };
B.diff = (a, b) => Math.round((B.parse(b) - B.parse(a)) / 864e5);   // b − a в днях
B.wd = s => (B.parse(s).getDay() + 6) % 7;                          // 0 = понедельник
B.weekStart = s => B.add(s, -B.wd(s));
B.MON = ['янв','фев','мар','апр','мая','июн','июл','авг','сен','окт','ноя','дек'];
B.MONG = ['января','февраля','марта','апреля','мая','июня','июля','августа','сентября','октября','ноября','декабря'];
B.MONF = ['Январь','Февраль','Март','Апрель','Май','Июнь','Июль','Август','Сентябрь','Октябрь','Ноябрь','Декабрь'];
B.WD = ['пн','вт','ср','чт','пт','сб','вс'];
B.WDF = ['понедельник','вторник','среда','четверг','пятница','суббота','воскресенье'];
B.fmt = s => { const d = B.parse(s); return `${d.getDate()} ${B.MONG[d.getMonth()]}`; };
B.fmtS = s => { const d = B.parse(s); return `${d.getDate()} ${B.MON[d.getMonth()]}`; };
B.fmtW = s => `${B.WD[B.wd(s)]}, ${B.fmtS(s)}`;
B.rel = s => {
  if (!s) return '';
  const k = B.diff(B.today(), s);
  if (k === 0) return 'сегодня';
  if (k === 1) return 'завтра';
  if (k === -1) return 'вчера';
  if (k > 1 && k < 7) return B.WDF[B.wd(s)];
  return B.fmtS(s);
};
B.hm = ts => { const d = new Date(ts); return `${pad(d.getHours())}:${pad(d.getMinutes())}`; };
B.mins = m => m < 60 ? `${m} мин` : `${Math.floor(m / 60)} ч${m % 60 ? ' ' + (m % 60) + ' мин' : ''}`;

/* ---------- хранилище ----------
   Все записи лежат документами в одной коллекции: cfg, p_<id> проекты, t_<id> задачи, h_<id> привычки,
   d_<дата> день (план, привычки, чтение, разбор, мысли), b_<id> книги, w_<id> тренировки.
   Копия всегда есть в localStorage. Изменения помечаются «грязными» и уходят в облако, пока не дойдут. */
const LS_DOCS = 'bamboo-docs', LS_DIRTY = 'bamboo-dirty';
let docs = {}, dirty = {}, db = null, firstSnap = false;
B.ver = 0;
try { docs = JSON.parse(localStorage.getItem(LS_DOCS) || '{}') || {}; } catch (e) { docs = {}; }
try { dirty = JSON.parse(localStorage.getItem(LS_DIRTY) || '{}') || {}; } catch (e) { dirty = {}; }
let lsT;
function persistLocal(){
  try { localStorage.setItem(LS_DOCS, JSON.stringify(docs)); localStorage.setItem(LS_DIRTY, JSON.stringify(dirty)); B.lsFull=false; }
  catch(e){if(!B.lsFull&&B.toast)B.toast('Память браузера заполнена. Войди в облако или освободи место.',8000);B.lsFull=true;}
  return !B.lsFull;
}
B.persistLocal = persistLocal;
function lsSave(){clearTimeout(lsT);lsT=setTimeout(persistLocal,120);}
addEventListener('pagehide',persistLocal);
document.addEventListener('visibilitychange',()=>{if(document.hidden)persistLocal();});
B.lsSize = () => JSON.stringify(docs).length;
B.sync = {mode: 'local', text: 'Только на этом устройстве'};
let documentSync = B.sync;
function refreshSync(){
  const count = Object.keys(shadQueue).length;
  B.sync = documentSync.mode === 'cloud' && count
    ? {mode: 'pending', text: 'Ожидают отправки изменения ШАД: ' + count}
    : documentSync.mode === 'cloud' && Object.keys(dirty).length
      ? {mode: 'pending', text: 'Отправляю изменения в облако…'}
      : documentSync;
  B.emit('sync');
}
function setSync(mode, text){ documentSync = {mode, text}; refreshSync(); }

const subs = {};
B.on = (ev, fn) => { (subs[ev] = subs[ev] || []).push(fn); };
B.emit = (ev, x) => (subs[ev] || []).forEach(f => { try { f(x); } catch (e) { console.error(e); } });
let raf = 0;
function changed(){ B.ver++; if (!raf) raf = requestAnimationFrame(() => { raf = 0; B.emit('change'); }); }
B.changed = changed;

B.get = id => docs[id];
B.list = prefix => { const out = []; for (const k in docs) if (k.startsWith(prefix)) out.push(docs[k]); return out; };
/* put(id, null) удаляет. quiet: не перерисовывать (для полей, куда сейчас печатают) */
/* ---------- отмена и повтор (Cmd+Z / Cmd+Shift+Z) ----------
   Каждая запись помнит, каким документ был до и после. Изменения, сделанные подряд за 0,8 с, отменяются одним шагом. */
const undoSt = [], redoSt = [];
let replaying = false, lastRec = 0;
function record(key, before, after){
  if (replaying) return;
  const now = Date.now(), cl = v => v == null ? null : JSON.parse(JSON.stringify(v));
  let e = undoSt[undoSt.length - 1];
  if (!e || now - lastRec > 800){ e = {items: {}}; undoSt.push(e); if (undoSt.length > 100) undoSt.shift(); }
  if (!(key in e.items)) e.items[key] = {before: cl(before)};
  e.items[key].after = cl(after);
  lastRec = now; redoSt.length = 0;
}
function replay(e, which){
  replaying = true;
  try {
    for (const k in e.items){
      const v = e.items[k][which];
      if (k.startsWith('shad:')) B.shadRestore(+k.slice(5), v);
      else B.put(k, v == null ? null : JSON.parse(JSON.stringify(v)));
    }
  } finally { replaying = false; }
}
B.undo = () => { const e = undoSt.pop(); if (!e) return false; replay(e, 'before'); redoSt.push(e); lastRec = 0; return true; };
B.redo = () => { const e = redoSt.pop(); if (!e) return false; replay(e, 'after'); undoSt.push(e); lastRec = 0; return true; };
B.recordShad = (n, before, after) => record('shad:' + n, before, after);
B.clearUndo = () => { undoSt.length = 0; redoSt.length = 0; };

B.put = (id, data, quiet) => {
  if (id !== 'cfg') record(id, docs[id], data);
  if (data == null) delete docs[id];
  else { if (data._seed) delete data._seed; docs[id] = data; }
  dirty[id] = (dirty[id] || 0) + 1;
  lsSave(); schedule(id);
  if (db && B.sync.mode === 'cloud') refreshSync();
  if (quiet) B.ver++; else changed();
};

const timers = {}, sending = {};
function schedule(id){ if (!db) return; clearTimeout(timers[id]); timers[id] = setTimeout(() => flush(id), 600); }
async function flush(id){
  if (!db || !dirty[id]) return;
  if (sending[id]) { schedule(id); return; }
  sending[id] = true;
  const v = dirty[id], data = docs[id];
  try {
    if (data == null) await db.doc('bamboo/' + id).delete();
    else await db.doc('bamboo/' + id).set(data);
    if (dirty[id] === v) delete dirty[id];
    lsSave();
    if (!Object.keys(dirty).length) setSync('cloud', 'Сохранено в облаке');
  } catch (e) {
    setSync('error', navigator.onLine ? 'Облако не ответило, копия на устройстве' : 'Нет интернета, копия на устройстве');
    clearTimeout(timers[id]); timers[id] = setTimeout(() => flush(id), 15000);
  } finally { sending[id] = false; }
}
function flushAll(){ Object.keys(dirty).forEach(flush); }
addEventListener('online', flushAll);

function onRemote(snap){
  const seen = new Set(); let ch = false;
  for (const d of snap.docs){
    seen.add(d.id);
    // нетронутая заготовка этого устройства уступает тому, что уже есть в облаке
    if (dirty[d.id] && !firstSnap && docs[d.id] && docs[d.id]._seed) delete dirty[d.id];
    if (dirty[d.id]) continue;
    const v = d.data();
    if (JSON.stringify(docs[d.id]) !== JSON.stringify(v)) { docs[d.id] = v; ch = true; }
  }
  for (const id of Object.keys(docs)) if (!seen.has(id) && !dirty[id]) { delete docs[id]; ch = true; }
  if (!firstSnap){
    firstSnap = true;
    if (!docs.cfg) seed();
    flushAll();
  }
  setSync('cloud', Object.keys(dirty).length ? 'Отправляю в облако…' : 'Синхронизировано, видно на всех устройствах');
  if (ch){ lsSave(); changed(); }
}

/* ---------- заготовка при первом запуске ---------- */
function seed(){
  const t = B.today();
  const mk = (id, data) => { if (!docs[id]) { docs[id] = Object.assign({_seed: true}, data); dirty[id] = 1; } };
  mk('cfg', {start: t, pomo: {work: 25, short: 5, long: 15, every: 4}, readGoal: 30, sportGoal: 3});
  mk('p_inbox', {id: 'inbox', name: 'Входящие', color: 'ink', order: 0});
  mk('p_uni', {id: 'uni', name: 'Вуз', color: 'blue', order: 1});
  mk('p_phys', {id: 'phys', name: 'Физика', parent: 'uni', color: 'blue', order: 2});
  mk('p_chem', {id: 'chem', name: 'Химия', parent: 'uni', color: 'teal', order: 3});
  mk('p_shad', {id: 'shad', name: 'ШАД', color: 'violet', order: 4});
  mk('p_life', {id: 'life', name: 'Личное', color: 'amber', order: 5});
  mk('h_read', {id: 'read', name: 'Чтение', icon: 'book', kind: 'daily', auto: 'read', min: 30, order: 0, created: t});
  mk('h_sport', {id: 'sport', name: 'Тренировка', icon: 'run', kind: 'weekly', target: 3, auto: 'sport', order: 1, created: t});
  mk('h_sleep', {id: 'sleep', name: 'Сон до 00:00', icon: 'moon', kind: 'daily', order: 2, created: t});
  lsSave(); changed();
  if (db) flushAll();
}

/* ---------- ШАД: план из ../shad/plan.json и отметки из коллекции 'shad' ---------- */
B.SHAD_STAGES = ['Не начат', 'Смотрю', 'Веб посмотрен', 'ДЗ сдано', 'Закрыт'];
B.shad = {plan: [], base: [], courses: {}, marks: {}, lms: ''};
const LS_SHADPLAN = 'bamboo-shadplan', LS_SHADMARKS = 'shad-track-progress';   // второй ключ общий с трекером shad/ на этом устройстве
function usePlan(d){
  B.shad.courses = d.courses || {}; B.shad.lms = d.lms || ''; B.shad.brk = d.break || null; B.shad.hours = d.hours || {web: 3.75, hw: 1.9};
  B.shad.base = (d.webs || []).map(x => ({n: x.n, c: x.course, code: x.code, t: x.title, lessonId: x.lessonId, w: x.web, h: x.hw,
    wk: x.web && x.web.date ? B.weekStart(x.web.date) : '', hk: x.hw && x.hw.date ? B.weekStart(x.hw.date) : ''}));
  applyOver(); changed();
}
/* правки вебов (название, дата и время веба, срок ДЗ) лежат в той же записи 'shad/wNN', поле o: {t, w, h}.
   Их видит и трекер shad/: перенёс веб в планере, он переехал и там.
   План раздаёт вебы и ДЗ по неделям (wk, hk — понедельник недели из плана). Пока у веба или ДЗ нет своего дня
   (o.w.date / o.h.date), он лежит в блоке «ШАД на неделю» планера; wp и hp — «поставлен на день». */
function applyOver(){
  B.shad.plan = B.shad.base.map(p => {
    const o = (B.shad.marks[p.n] || {}).o; if (!o) return p;
    return Object.assign({}, p, {t: o.t || p.t, w: o.w ? Object.assign({}, p.w, o.w) : p.w, h: o.h ? Object.assign({}, p.h, o.h) : p.h, edited: true,
      wp: !!(o.w && o.w.date), hp: !!(o.h && o.h.date)});
  });
}
B.shadBase = n => B.shad.base.find(p => p.n === n);
const shadKeep = v => v.s || v.note || v.o;
const LS_SHAD_QUEUE = 'bamboo-shad-pending';
let shadQueue = {};
const shadSending = new Set(), shadTimers = {};
try { shadQueue = JSON.parse(localStorage.getItem(LS_SHAD_QUEUE) || '{}') || {}; } catch (_) {}
B.shadPending = n => !!shadQueue[n];
function cacheShad(){
  try {
    localStorage.setItem(LS_SHADMARKS, JSON.stringify(B.shad.marks));
    localStorage.setItem(LS_SHAD_QUEUE, JSON.stringify(shadQueue));
  } catch (_) {}
}
function shadWrite(n,v){
  if (db || localStorage.getItem('bv_code')) shadQueue[n]=v;
  cacheShad(); refreshSync();
  return flushShad(n);
}
async function flushShad(n){
  if (!db || !shadQueue[n] || shadSending.has(n)) return;
  clearTimeout(shadTimers[n]);
  shadSending.add(n);
  const v = shadQueue[n];
  let saved = false;
  try {
    const ref = db.doc('shad/w' + pad(n));
    if (!shadKeep(v)) await ref.delete();
    else await ref.set(v);
    saved = true;
    if (shadQueue[n] === v) delete shadQueue[n];
    refreshSync(); changed();
    cacheShad();
  } catch (_) {
    shadTimers[n] = setTimeout(() => flushShad(n),15000);
  } finally {
    shadSending.delete(n);
    if (saved && shadQueue[n]) flushShad(n);
  }
}
function overlayShad(m){
  for (const n in shadQueue){
    const v = shadQueue[n];
    if (shadKeep(v)) m[n]=v;
    else delete m[n];
  }
  return m;
}
function flushShadQueue(){ Object.keys(shadQueue).forEach(flushShad); }
/* patch: {t, w: {date, from, to}, h: {date}}; null убирает все правки, веб снова как в плане */
B.shadRestore = (n, v) => {
  const m = Object.assign({}, B.shad.marks);
  if (v) m[n] = v; else delete m[n];
  B.shad.marks = m; applyOver(); changed(); shadWrite(n, v || {s: 0, note: ''});
};
B.setShadOver = (n, patch) => {
  const cur = B.shad.marks[n] || {}, base = B.shadBase(n); if (!base) return;
  let o = null;
  if (patch){
    o = JSON.parse(JSON.stringify(cur.o || {}));
    if ('t' in patch) o.t = (patch.t || '').trim() && patch.t.trim() !== base.t ? patch.t.trim() : undefined;
    ['w', 'h'].forEach(k => {
      if (!patch[k]) return;
      const m = Object.assign({}, o[k] || {}, patch[k]);
      // свой день хранится, даже если совпал с днём из плана (это значит «поставлен»); пустой день убирает его
      Object.keys(m).forEach(f => { if (f === 'date' ? !m.date : (m[f] || '') === (base[k][f] || '')) delete m[f]; });
      o[k] = Object.keys(m).length ? m : undefined;
    });
    o = JSON.parse(JSON.stringify(o));
    if (!Object.keys(o).length) o = null;
  }
  const v = {...cur, s: cur.s || 0, note: cur.note || ''}; if (o) v.o = o; else delete v.o;
  B.recordShad(n, B.shad.marks[n], v);
  B.shad.marks = Object.assign({}, B.shad.marks, {[n]: v});
  applyOver(); changed(); shadWrite(n, v);
};
let shadPlanJSON = '', shadPlanLoading = false;
function showShadPlan(data){
  if (!data || !Array.isArray(data.webs) || !data.webs.length || !data.courses ||
      !data.webs.every(w => Number.isInteger(w?.n) && data.courses[w.course] && w.web?.date)) return;
  const json = JSON.stringify(data);
  if (json === shadPlanJSON) return;
  usePlan(data);
  shadPlanJSON = json;
  try { localStorage.setItem(LS_SHADPLAN, json); } catch (_) {}
}
async function loadShadPlan(){
  if (shadPlanLoading) return;
  shadPlanLoading = true;
  const bundled = ['appassets.androidplatform.net', '127.0.0.1:49191'].includes(location.host);
  const localPlan = '../shad/plan.json?v=2';
  try {
    if (!shadPlanJSON){
      try { showShadPlan(JSON.parse(localStorage.getItem(LS_SHADPLAN))); } catch (_) {}
    }
    if (bundled && !shadPlanJSON){
      try {
        const local = await fetch(localPlan);
        if (local.ok) showShadPlan(await local.json());
      } catch (_) {}
    }
    const url = bundled ? 'https://kopejkingeorgij09-web.github.io/BioVision/shad/plan.json' : localPlan;
    const abort = new AbortController();
    const timer = setTimeout(() => abort.abort(), 12000);
    try {
      const response = await fetch(url, {cache: 'no-store', credentials: 'omit', signal: abort.signal});
      if (response.ok) showShadPlan(await response.json());
    } finally { clearTimeout(timer); }
  } catch (_) {
    // Offline: keep the last plan successfully loaded on this device.
  } finally { shadPlanLoading = false; }
}
function onShad(snap){
  const m = {};
  snap.docs.forEach(d => { const n = parseInt(d.id.slice(1), 10); const v = d.data() || {}; if (n){ m[n] = {s: v.s || 0, note: v.note || '', at: v.at || 0}; if (v.o) m[n].o = v.o; } });
  overlayShad(m);
  if (JSON.stringify(m) !== JSON.stringify(B.shad.marks)){ B.shad.marks = m; cacheShad(); applyOver(); changed(); }
}
/* бонус за качество ДЗ с «Фагов» (до +10 за веб): его пишет сервер в коллекцию 'shadx', когда ДЗ проверено */
B.shad.bonus = {};
function onShadX(snap){
  const m = {};
  snap.docs.forEach(d => { const n = parseInt(d.id.slice(1), 10); const v = d.data() || {}; if (n && v.b) m[n] = {b: +v.b || 0, at: v.at || 0}; });
  if (JSON.stringify(m) !== JSON.stringify(B.shad.bonus)){ B.shad.bonus = m; changed(); }
}
/* лента с «Фагов» (коллекция 'phx', пишет сервер, см. supabase/migrations/20261104c_phagi_bamboo_bridge.sql):
   ev_<id> занятия (в «Зове леса» не показываются), dl_<id> сроки ДЗ, day_<дата> что было на Фагах за день */
B.phx = {ev: {}, dl: {}, day: {}};
B.PHAGI = !['appassets.androidplatform.net','127.0.0.1:49191'].includes(location.host) && /^https?:$/.test(location.protocol) ? '../phagi/' : 'https://kopejkingeorgij09-web.github.io/BioVision/phagi/';
B.phagiLink = params => B.PHAGI + '?' + new URLSearchParams({...params, from:'forest', back:location.hash || '#/today'});
B.phagiTask = (id,day) => B.phagiLink({task:id, role:'student', ...(day?{backDay:day}:{})});
B.teaching = null;
let loadingTeaching = false;
async function refreshTeaching(){
  if (!B.cloud || loadingTeaching || (document.hidden && B.teaching && !B.teaching.failed)) return;
  loadingTeaching = true;
  try {
    const week = await BVAUTH.teachingWeek(B.today());
    if (JSON.stringify(week) !== JSON.stringify(B.teaching)){ B.teaching = week; changed(); }
  } catch { if (!B.teaching){ B.teaching = {failed:true}; changed(); } }
  finally { loadingTeaching = false; }
}
B.refreshTeaching = refreshTeaching;
window.addEventListener('pageshow', refreshTeaching);
window.addEventListener('focus', refreshTeaching);
document.addEventListener('visibilitychange', refreshTeaching);
setInterval(refreshTeaching, 60000);
function onPhx(snap){
  const m = {ev: {}, dl: {}, day: {}};
  snap.docs.forEach(d => { const i = d.id.indexOf('_'), k = d.id.slice(0, i), id = d.id.slice(i + 1); if (m[k]) m[k][id] = Object.assign({id}, d.data() || {}); });
  if (JSON.stringify(m) !== JSON.stringify(B.phx)){ B.phx = m; changed(); }
}
/* сроки ДЗ с Фагов на день. Занятия (ev_) в планер не берём: они часто меняются, их держат только на Фагах (просьба Георгия 4.11.2026) */
B.phxOn = date => {
  const out = [];
  for (const id in B.phx.dl){ const x = B.phx.dl[id]; if (x.due === date) out.push({k: 'dl', id, t: x.title, done: !!x.done, checked: !!x.checked, shad: x.shad, fix: x.fix}); }
  return out;
};
B.phxDay = date => B.phx.day[date] || null;
B.shadStage = n => (B.shad.marks[n] && B.shad.marks[n].s) || 0;
B.setShadStage = async (n, s) => {
  const cur = B.shad.marks[n] || {};
  const v = {s, note: cur.note || '', at: Date.now()}; if (cur.o) v.o = cur.o;
  B.recordShad(n, B.shad.marks[n], v);
  B.shad.marks = Object.assign({}, B.shad.marks, {[n]: v});
  changed();
  await shadWrite(n, v);
};
/* веб и ДЗ, поставленные на конкретный день */
B.shadOn = date => {
  const out = [];
  B.shad.plan.forEach(p => {
    if (p.wp && p.w.date === date) out.push({p, kind: 'web', from: p.w.from || '', to: p.w.to || '', need: 2});
    if (p.hp && p.h.date === date) out.push({p, kind: 'hw', from: p.h.from || '', to: p.h.to || '', need: 3});
  });
  return out.sort((a, b) => a.from.localeCompare(b.from));
};
/* блок «ШАД на неделю»: вебы и ДЗ этой недели, которым ещё не выбран день */
B.shadWeek = ws => {
  const out = [];
  B.shad.plan.forEach(p => {
    if (p.w && !p.wp && p.wk === ws) out.push({p, kind: 'web', need: 2});
    if (p.h && p.h.date && !p.hp && p.hk === ws) out.push({p, kind: 'hw', need: 3});
  });
  return out.sort((a, b) => a.p.n - b.p.n || (a.kind === 'web' ? -1 : 1));
};
B.shadWeekAll = ws => {
  const we = B.add(ws, 6), out = B.shadWeek(ws);
  B.shad.plan.forEach(p => {
    if (p.wp && p.w.date >= ws && p.w.date <= we) out.push({p, kind: 'web', need: 2});
    if (p.hp && p.h.date >= ws && p.h.date <= we) out.push({p, kind: 'hw', need: 3});
  });
  return out;
};
B.shadHoursLeft = list => list.reduce((m, it) => m + (B.shadStage(it.p.n) >= it.need ? 0 : (B.shad.hours || {})[it.kind] || 0), 0);
/* убрать день у веба или ДЗ: карточка вернётся в блок своей недели */
B.shadUnplace = (n, kind) => {
  const base = B.shadBase(n), k = kind === 'web' ? 'w' : 'h'; if (!base || !base[k]) return;
  B.setShadOver(n, {[k]: {date: '', from: '', to: ''}});
};
/* хвосты: поставленное на прошедший день или не поставленное, когда неделя уже кончилась */
B.shadLate = () => {
  const t = B.today(), ws = B.weekStart(t), out = [];
  B.shad.plan.forEach(p => {
    const s = B.shadStage(p.n);
    const wl = p.w && (p.wp ? p.w.date < t : p.wk < ws), hl = p.h && p.h.date && (p.hp ? p.h.date < t : p.hk < ws);
    if (s < 2 && wl) out.push({p, kind: 'web', need: 2});
    else if (s < 3 && hl) out.push({p, kind: 'hw', need: 3});
  });
  return out;
};

/* ---------- подключение ---------- */
let connecting = false;
B.connect = async (retry = false) => {
  if (db || connecting) return;
  connecting = true;
  if (!retry) loadShadPlan();
  const me = window.BVAUTH ? await (retry ? BVAUTH.restore() : BVAUTH.ready) : null;
  if (me && me.role === 'admin' && window.claude){
    try { db = await window.claude.use('db'); } catch (e) { db = null; }
  }
  connecting = false;
  B.cloud = !!db;
  if (db){
    setSync('cloud', 'Синхронизирую…');
    db.collection('bamboo').onSnapshot(onRemote, () => setSync('error', navigator.onLine ? 'Облако не ответило, копия на устройстве' : 'Нет интернета, копия на устройстве'));
    db.collection('shad').onSnapshot(onShad, () => {});
    flushShadQueue();
    db.collection('shadx').onSnapshot(onShadX, () => {});
    db.collection('phx').onSnapshot(onPhx, () => {});
    refreshTeaching();
  } else {
    if (!docs.cfg) seed();
    try { B.shad.marks = overlayShad(JSON.parse(localStorage.getItem(LS_SHADMARKS) || '{}') || {}); } catch (e) {}
    applyOver();
    let had = ''; try { had = localStorage.getItem('bv_code') || ''; } catch (e) {}
    setSync(had ? 'error' : 'local', had ? 'Нет связи с облаком, записи пока только здесь' : 'Только на этом устройстве · войди кодом для синхронизации');
    changed();
  }
};
let lastRefresh = 0;
function refreshCloud(){
  if (Date.now() - lastRefresh < 1800) return;
  lastRefresh = Date.now();
  loadShadPlan();
  if (db){ flushShadQueue(); dispatchEvent(new Event('bv-cloud-write')); }
  else if (localStorage.getItem('bv_code')) B.connect(true);
}
addEventListener('online', refreshCloud);
document.addEventListener('visibilitychange', () => { if (!document.hidden) refreshCloud(); });

B.exportAll = () => ({app: 'bamboo', at: new Date().toISOString(), docs, version: 2, shadMarks: B.shad.marks});
B.importAll = obj => {
  if (!obj || obj.app !== 'bamboo' || !obj.docs) throw new Error('Это не резервная копия «Зова леса»');
  const marks = Object.entries(obj.shadMarks || {});
  if (marks.some(([n,v]) => !/^[1-9]\d*$/.test(n) || !v || !Number.isInteger(v.s) || v.s < 0 || v.s > 4)) throw new Error('Некорректные отметки ШАД');
  for (const [n,v] of marks) B.shadRestore(+n,v);
  for (const id in obj.docs) B.put(id, obj.docs[id], true);
  changed();
};

/* ---------- модель ---------- */
B.cfg = () => Object.assign({start: B.today(), pomo: {work: 25, short: 5, long: 15, every: 4}, readGoal: 30, sportGoal: 3}, docs.cfg || {});
B.setCfg = patch => B.put('cfg', Object.assign({}, docs.cfg || {}, patch));
B.projects = () => B.list('p_').filter(p => !p.arch).sort((a, b) => (a.order || 0) - (b.order || 0));
B.proj = id => docs['p_' + id];
B.projName = id => { const p = B.proj(id); if (!p) return ''; const par = p.parent && B.proj(p.parent); return par ? par.name + ' · ' + p.name : p.name; };
B.tasks = () => B.list('t_').filter(t => !t.deleted);   // удалённые из планов прошлых дней остаются скрытыми, чтобы итоги дней не менялись
B.task = id => docs['t_' + id];
B.saveTask = (t, quiet) => {
  if (t.repPristine && B.task(t.id)){ t = {...t}; delete t.repPristine; }
  B.put('t_' + t.id, t, quiet);
  if (quiet) B.androidReminders?.queue();
};
B.day = date => docs['d_' + date] || {};
B.dayDates = () => Object.keys(docs).filter(k => k.startsWith('d_')).map(k => k.slice(2)).sort();
B.datesWith = id => Object.keys(docs).filter(k => k.startsWith('d_') && (docs[k].top || []).includes(id)).map(k => k.slice(2));
B.saveDay = (date, d, quiet) => B.put('d_' + date, d, quiet);
B.editDay = (date, fn, quiet) => { const d = JSON.parse(JSON.stringify(B.day(date))); fn(d); B.saveDay(date, d, quiet); };
B.habits = () => B.list('h_').filter(h => !h.arch).sort((a, b) => (a.order || 0) - (b.order || 0));
B.habitPins = () => {
  const ids = B.get('habitPins')?.ids;
  return Array.isArray(ids) ? [...new Set(ids)].filter(id => {
    const h = B.get('h_' + id);
    return h && !h.arch;
  }).slice(0, 2) : [];
};
B.trackerHabits = () => {
  const pins = B.habitPins(), habits = B.habits();
  return pins.map(id => B.get('h_' + id)).concat(habits.filter(h => !pins.includes(h.id)));
};

B.books = () => B.list('b_');
B.workouts = () => B.list('w_').sort((a, b) => (b.date + (b.at || 0)).localeCompare(a.date + (a.at || 0)));
B.readMin = date => (B.day(date).read || []).reduce((a, r) => a + (r.min || 0), 0);

B.newTask = o => Object.assign({id: B.uid(), title: '', proj: 'inbox', pri: 4, due: '', time: '', est: 0,
  done: false, status: 'todo', big: false, subs: [], notes: '', created: Date.now(), postpones: []}, o);
B.setDone = (t, v) => {
  t = Object.assign({}, t, {done: v, status: v ? 'done' : (t.status === 'done' ? 'todo' : t.status), doneAt: v ? Date.now() : null});
  B.saveTask(t);
  return t;
};
B.nextStep = t => (t.subs || []).find(s => !s.done);

/* ---------- опыт, уровни, серии ----------
   Опыт дают только дела и привычки: задача +5 (важная или с короной +8), подзадача +4,
   привычка +10 (минимальная версия +5; чтение и тренировка тоже привычки и считаются здесь же).
   Фокус, чтение минутами и разбор опыта не дают: они видны в своих разделах и сериях.
   Каждый новый уровень сажает в лесу новое дерево, растущее дерево показывает прогресс внутри уровня. */
B.XP = {task: 5, taskP1: 8, sub: 4, habit: 10,
  // ШАД ценится выше обычных дел: опыт по достигнутой стадии веба (Смотрю, Посмотрен, ДЗ решено, Закрыт), всего до 60 за веб
  shad: [0, 5, 20, 50, 60]};
B.need = L => 100 + 25 * L;           // опыта от уровня L до L+1

B.levelOf = total => {
  let L = 1, rem = total;
  while (rem >= B.need(L)) { rem -= B.need(L); L++; }
  const frac = rem / B.need(L);
  return {L, rem, frac, trees: L - 1};
};
/* сколько всего опыта нужно, чтобы дойти до уровня L */
B.xpForLevel = L => { let xp = 0; for (let k = 1; k < L; k++) xp += B.need(k); return xp; };
/* 1 — привычка выполнена, 0.5 — минимальная версия (держит серию, половина опыта), 0 — нет */
B.habitVal = (h, date) => {
  if (h.auto === 'molbio' && date >= (h.molbioSince || '2026-11-16')) return B.alberts?.pagesOn(date) > 0 ? 1 : 0;
  if (h.auto === 'molbio') h = Object.assign({},h,{auto:'read'});
  if (h.auto === 'read'){
    const m = B.readMin(date);
    if (m >= (h.min || 30)) return 1;
    return h.mini && m >= (h.miniMin || 10) ? 0.5 : 0;
  }
  if (h.auto === 'sport') return sportSet().has(date) ? 1 : 0;
  const d = B.day(date), v = d.h && d.h[h.id];
  // карточки на «Фагах»: от h.min (по умолчанию 10) повторённых за день отмечается сама, ручная отметка тоже считается
  if (h.auto === 'cards' && !v){ const x = B.phxDay(date); return x && (x.cards || 0) >= (h.min || 10) ? 1 : 0; }
  return v ? (v === 0.5 ? 0.5 : 1) : 0;
};
B.habitDone = (h, date) => B.habitVal(h, date) > 0;
let sportMemo = null, sportVer = -1;
function sportSet(){ if (sportVer !== B.ver){ sportMemo = new Set(B.list('w_').map(w => w.date)); sportVer = B.ver; } return sportMemo; }
B.hasReview = d => !!((d.notebook || '').trim() || (d.review && ((d.review.done || '').trim() || (d.review.why || '').trim())));
/* разбор засчитан, если начат до конца дня (до 4 утра); задним числом не считается */
B.reviewDone = date => {
  const d = B.day(date), r = d.review || {};
  if (!B.hasReview(d)) return false;
  const first = (d.notebook || '').trim() ? d.notebookFirst || d.notebookAt : r.first || r.at;
  return !(first && B.dayOf(first) > date);
};
/* серия дней подряд, где test(date) верно; сегодняшний пропуск серию пока не рвёт */
B.streakOf = (test, from) => {
  const t = B.today(); from = from || B.cfg().start;
  let cur = 0, d = test(t) ? t : B.add(t, -1);
  while (d >= from && test(d)){ cur++; d = B.add(d, -1); }
  let best = 0, run = 0;
  for (let x = from; x <= t; x = B.add(x, 1)){ if (test(x)){ run++; best = Math.max(best, run); } else if (x < t) run = 0; }
  return {cur, best};
};
let memo = null, memoKey = '';
B.calc = () => {
  const today = B.today();
  const key = B.ver + '|' + today;
  if (memo && memoKey === key) return memo;
  const cfg = B.cfg(), start = cfg.start || today;
  const tasks = B.tasks(), habits = B.list('h_');   // и архивные: опыт до дня архивации остаётся
  const doneBy = {}, subBy = {}, postBy = {}, sportBy = {}, shadBy = {};
  const push = (o, k, v) => (o[k] = o[k] || []).push(v);
  tasks.forEach(t => {
    if (t.done && t.doneAt) push(doneBy, B.dayOf(t.doneAt), t);
    (t.subs || []).forEach(s => { if (s.done && s.doneAt) push(subBy, B.dayOf(s.doneAt), s); });
    (t.postpones || []).forEach(p => push(postBy, B.dayOf(p.at), p));
  });
  B.workouts().forEach(w => push(sportBy, w.date, w));
  // сданное ДЗ с «Фагов» — как сделанная задача (+5); ДЗ к вебам ШАДа не считаются здесь, их опыт идёт через стадию веба
  const phBy = {};
  for (const id in B.phx.dl){ const x = B.phx.dl[id]; if (x.done && x.doneAt && !x.shad) push(phBy, x.doneAt, x); }
  for (const n in B.shad.marks){ const m = B.shad.marks[n]; if (m.at && m.s) push(shadBy, B.dayOf(m.at), m.s); }
  const shadXBy = {};   // бонус за проверенное ДЗ ШАДа, пока веб в стадии «ДЗ решено» или «Закрыт»
  for (const n in B.shad.bonus){ const m = B.shad.bonus[n]; if (m.at && m.b && B.shadStage(+n) >= 3) push(shadXBy, B.dayOf(m.at), m.b); }

  const days = {}, weekHab = {};
  let total = 0, xpAll = 0;
  const N = Math.max(0, B.diff(start, today));
  for (let i = 0; i <= N; i++){
    const date = B.add(start, i), d = B.day(date), ws = B.weekStart(date);
    const p = {};
    const top = (d.top || []).map(B.task).filter(t => t && (!t.deleted || date < today));
    const crownSet = new Set(top.map(t => t.id));
    const dn = doneBy[date] || [];
    if (dn.length) p.tasks = dn.reduce((a, t) => a + (t.pri === 1 || crownSet.has(t.id) ? B.XP.taskP1 : B.XP.task), 0);
    if (subBy[date]) p.subs = subBy[date].length * B.XP.sub;
    if (phBy[date]) p.tasks = (p.tasks || 0) + phBy[date].length * B.XP.task;
    if (shadBy[date]) p.shad = shadBy[date].reduce((x, st) => x + (B.XP.shad[st] || 0), 0);   // весь опыт веба в день последней отметки
    if (shadXBy[date]) p.shad = (p.shad || 0) + shadXBy[date].reduce((x, b) => x + b, 0);
    let hab = 0;
    habits.forEach(h => {
      if (h.created && date < h.created) return;
      if (h.arch && h.archAt && date >= h.archAt) return;
      const hv = B.habitVal(h, date);
      if (!hv) return;
      if (h.kind === 'weekly'){
        const k = h.id + ws; weekHab[k] = (weekHab[k] || 0) + 1;
        if (weekHab[k] > (h.target || 3)) return;
      }
      hab += hv;
    });
    if (hab) p.habits = Math.round(hab * B.XP.habit);
    const rm = (d.read || []).reduce((a, r) => a + (r.min || 0), 0);
    const rvOk = B.reviewDone(date);

    let xp = 0; for (const k in p) xp += p[k];
    // день: разбор есть — «good»; что-то сделано без разбора — «some»; пусто — «empty»
    const active = dn.length || hab || rm || sportBy[date] || subBy[date] || phBy[date];
    const result = date >= today ? 'open' : rvOk ? 'good' : active ? 'some' : 'empty';
    xpAll += Math.max(0, xp);
    total = Math.max(0, total + xp);
    days[date] = {xp, p, result, total, done: dn.length, review: rvOk, reviewText: B.hasReview(d)};
  }
  // уровень и лес
  const {L, rem, frac, trees} = B.levelOf(total);
  const doneDay = date => !!(days[date] && days[date].done);
  const rv = B.streakOf(date => !!(days[date] && days[date].review), start);
  const tk = B.streakOf(doneDay, start);
  const reviews = Object.values(days).filter(x => x.review).length, empty = Object.values(days).filter(x => x.result === 'empty').length;
  memo = {days, total, level: L, into: rem, need: B.need(L), frac, trees, xpAll, start, today,
    live: rv.cur, best: rv.best, review: rv, tasks: tk, reviews, empty};
  memoKey = key;
  return memo;
};

/* ---------- вехи леса ----------
   Уровень L: в лесу L − 1 взрослых деревьев и одно растущее. Вехи по уровню. */
B.MILES = [
  [1, 'Семечко', 'всё начинается с одного семечка'],
  [2, 'Первое дерево', 'первое взрослое дерево на поляне'],
  [3, 'Пара деревьев', 'уже не одинокое дерево'],
  [5, 'Островок', 'маленький островок зелени'],
  [8, 'Опушка', 'появились первые грибы и тропинка'],
  [12, 'Рощица', 'деревья стоят кружком'],
  [17, 'Роща', 'в роще поселились птицы'],
  [23, 'Лесок', 'тень на всей поляне'],
  [30, 'Лес', 'настоящий лес, можно заблудиться'],
  [40, 'Бор', 'высокие сосны и мох под ногами'],
  [52, 'Дубрава', 'вековые дубы'],
  [66, 'Чаща', 'тропинки зарастают'],
  [82, 'Тайга', 'лес до горизонта'],
  [100, 'Заповедник', 'сюда приходят олени'],
  [130, 'Древний лес', 'лесу больше, чем любому дереву в нём'],
  [170, 'Лесной край', 'зелёный цвет на карте']
];
B.mileFor = L => {
  let prev = null, next = null;
  for (const m of B.MILES){ if (m[0] <= L) prev = m; else { next = m; break; } }
  return {prev, next};
};
B.fmtTrees = n => `${n} ${B.plural(n, 'дерево', 'дерева', 'деревьев')}`;
})();
